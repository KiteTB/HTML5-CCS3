<?php
    error_reporting(E_ALL & ~E_NOTICE);
    //开启会话
    session_start();
    //包含所有Composer的组件库
    require('vendor/autoload.php');
    require('class/cattree.php');

    use NoahBuscher\Macaw\Macaw;

    //进入管理平台的首页面
    Macaw::get('/admin', "admin\Index@index");

    //前台首页控制器
    Macaw::get('/', 'home\Index@index');   // 首页
    Macaw::get('/plist/(:num)', 'home\Product@plist');  // 产品列表页面
    Macaw::get('/product/(:num)', 'home\Product@index');  // 产品详情页面


    // 用户注册、登录、退出
    Macaw::any("/user/register", 'home\User@register');
    Macaw::any("/user/login", 'home\User@login');
    Macaw::any("/user/logout", 'home\User@logout');


    Macaw::get('/order/cartadd', 'home\Order@cartadd');   // 添加购物车
    Macaw::get('/order/cartnum', 'home\Order@cartnum');   // 添加购物车
    Macaw::get('/order/pay/(:num)', 'home\Order@pay');   // 支付
    Macaw::any('/order/add', 'home\Order@add');   // 添加订单

    Macaw::dispatch();   //解析显示输出内容

