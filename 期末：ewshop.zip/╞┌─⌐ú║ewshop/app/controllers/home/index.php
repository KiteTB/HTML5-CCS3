<?php
    namespace home;

    use models\BaseDao;

    class Index extends Home {
        function index() {
            $db  = new BaseDao();

            // 分类数据
            $cats = $db->select('category', ['id', 'catname'], ['pid'=>0, 'ORDER'=>['ord'=>'ASC', 'id'=>'DESC']]);

            $allcats = array();
            foreach($cats as $cat){

                //分类
                $cat['newlists'] = $db->select('product',
                    ['id', 'name', 'logo', 'money', 'smoney'],
                    ['cid'=>$cat['id'], 'state'=>1, 'ORDER'=>['id'=>'DESC'], 'LIMIT'=>8]);

                //热销分类
                $cat['selllists'] = $db->select('product',
                    ['id', 'name', 'logo', 'money', 'smoney'],
                    ['cid'=>$cat['id'], 'state'=>1, 'ORDER'=>['sellnum'=>'DESC'], 'LIMIT'=>5]);

                array_push($allcats, $cat);
            }

           $this->assign('allcats', $allcats);


            // 首页展示
            $this->assign('title', '首页');
            $this->display('index/index');
        }
    }
