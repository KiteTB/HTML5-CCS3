<?php
    namespace models;

    use Medoo\Medoo;

    class BaseDao extends Medoo {
        function __construct()
        {
            // Initialize
            $options = [
                'database_type' => 'mysql',
                'database_name' => 'ewshop',
                'server' => 'localhost',
                'port' => '3306',
                'username' => 'root',
                'charset' => 'utf8',
                'password' => '123456',
                'prefix' => TABPREFIX
            ];
            parent::__construct($options);
        }
    }

