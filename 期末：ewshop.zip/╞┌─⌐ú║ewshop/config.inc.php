<?php
    define("TEMPDIR", __DIR__);
    define("TEMPNAME", "home");  // home2  default  public

    define("HOST", 'localhost');
    define("PORT", '3306');
    define("USER", 'root');
    define("PASS", '123456');
    define("DBNAME", 'ewshop');
    define("TABPREFIX", 'ew_');

    define('PNUM', 10);
